
<?php $__env->startSection('title'); ?>
    DIENG VOKASI UNIVERSITAS BRAWIJAYA
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>
        <div class="section-body ">
            <div class="card">
                <div class="card-header-action">
                    <div class="card-header">
                        <ul class="mr-auto"></ul>
                        <form action="<?php echo e(route('list::index')); ?>">
                            <div class="input-group">
                                <input type="text" name="name" class="form-control" placeholder="Search" width="1rem"
                                    height="2rem">
                                <div class="input-group-btn">
                                    <button class="btn btn-primary text-white">Cari</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card-body p-0">
                    <table class="table table-bordered">
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Jabatan</th>
                            <th scope="col">Fakultas</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td>
                                    <?php if($user->status == 100): ?>
                                        <span class="badge badge-danger">Belum Diambil</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Sudah Diambil</span>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal<?php echo e($user->id); ?>">Aw,
                                        yeah!</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            <div class="card-footer text-right">
                <nav class="d-inline-block">
                    <ul class="pagination mb-0">
                        <?php echo e($users->appends([
                                'name' => request()->input('name'),
                            ])->links()); ?>

                    </ul>
                </nav>
            </div>
        </div>
    </section>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" tabindex="100" role="dialog" id="exampleModal<?php echo e($user->id); ?>">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Konfirmasi</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <dt>Nama</dt>
                        <dd><?php echo e($user->name); ?></dd>
                    </div>
                    <div class="modal-footer bg-whitesmoke br">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <a href="<?php echo e(route('api::index',[$user])); ?>" class="btn btn-primary">Hadir</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Developer\Code\premium\vokasi-app\resources\views/pages/main/user/index.blade.php ENDPATH**/ ?>