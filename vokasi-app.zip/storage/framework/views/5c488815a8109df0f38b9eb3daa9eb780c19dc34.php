
<?php $__env->startSection('title'); ?>
    User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="<?php echo e(route('admin::dashboard')); ?>">Dashboard</a></div>
                <div class="breadcrumb-item"><?php echo $__env->yieldContent('title'); ?></div>
            </div>
        </div>

        <div class="section-body">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('admin::users::create')); ?>" class="btn btn-primary mr-auto">Tambah User +</a>
                    <div class="card-header-action">
                        <form action="<?php echo e(route('admin::users::index')); ?>">
                            <div class="input-group">
                                <input type="text" name="name" class="form-control" placeholder="Search">
                                <div class="input-group-btn">
                                    <button class="btn btn-primary text-white">Cari</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card-body p-0">
                    <table class="table table-bordered">
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Jabatan</th>
                            <th>Fakultas</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->jabatan); ?></td>
                                <td><?php echo e($user->fakultas); ?></td>
                                <td>
                                    <?php if($user->status == 100): ?>
                                        <span class="badge badge-danger">Belum ambil hadiah</span>
                                    <?php elseif($user->status == 1): ?>
                                        <span class="badge badge-warning">Pending</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Sudah ambil hadiah</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin::users::view', [hashid_encode($user->id, 'user')])); ?>"
                                        class="btn btn-link">Rincian</a>
                                    <?php if($user->status == \App\Models\User::STATUS_DEFAULT): ?>
                                        <a href="javascript:"
                                            onclick="if(confirm('Hadiah <?php echo e($user->name); ?> akan diambil')){$('#get-item-<?php echo e($user->id); ?>').submit()}"
                                            class="btn btn-primary">Ubah Status</a>
                                        <form action="<?php echo e(route('api::index', [$user])); ?>" method="get"
                                            class="hidden" id="get-item-<?php echo e($user->id); ?>">
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <div class="card-footer text-right">
                    <nav class="d-inline-block">
                        <ul class="pagination mb-0">
                            <?php echo e($users->links()); ?>

                        </ul>
                    </nav>
                </div>
            </div>



        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Developer\Code\premium\vokasi-app\resources\views/pages/admin/users/index.blade.php ENDPATH**/ ?>