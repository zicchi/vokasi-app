
<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>
        <div class="section-body">
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Reset Kehadiran</div>
                    <div class="card-body"><a href="<?php echo e(route('admin::reset')); ?>" class="btn btn-primary btn-block">Reset</a></div>
                    <div class="card-footer text-muted text-center"><i>Fitur ini untuk cadangan jika fitur reset otomatis tidak dapat digunakan</i></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Jumlah Kehadiran</div>
                    <div class="card-body text-large">
                        <h3>0</h3>
                    </div>
                    <div class="card-footer text-muted text-center"><i>Jumlah hadir pada <?php echo e(now()->format('d, M Y')); ?></i></div>
                </div>
            </div>
        </div>
        </div>
        <div class="col-md-4">



        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Developer\Code\premium\vokasi-app\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>