<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('admin::dashboard')); ?>">Titian</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('admin::dashboard')); ?>">T</a>
        </div>
        <ul class="sidebar-menu">
            <li class="<?php echo e(request()->is('admin/dashboard*') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('admin::dashboard')); ?>"><i class="fas fa-fire"></i> <span>Dashboard</span></a></li>
            <li class="<?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('admin::users::index')); ?>"><i class="fas fa-user"></i> <span>User</span></a></li>
        </ul>
    </aside>
</div>
<?php /**PATH D:\Developer\Code\premium\vokasi-app\resources\views/includes/admin_sidebar.blade.php ENDPATH**/ ?>